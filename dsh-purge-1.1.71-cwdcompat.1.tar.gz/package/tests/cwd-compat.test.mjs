import assert from "node:assert/strict";
import { test } from "node:test";
import { readFile } from "node:fs/promises";
import { pathToFileURL } from "node:url";
import { removeLegacyCwdSentence } from "../lib/legacy-cwd.js";
import { rewritePromptAssembly } from "../lib/identity.js";

const rendererPath = process.env.DSH_RENDERER_PATH;
const { renderPrompt, renderContextSections } = rendererPath
  ? await import(pathToFileURL(rendererPath).href)
  : {};
const variables = { provider: "deepseek-official", model: "deepseek-v4-pro" };
const context = {
  name: "working-directory:current",
  text: 'Current working directory: "/workspace/current".',
  interpolate: false,
};
const fixtures = [
  "",
  "Your working directory is {{cwd}}.",
  "Working directory: {{cwd}}.",
  "Working directory: {{cwd}}",
  "You are a coding agent powered by the {{model}} model, running on the DeepSeek Harness. Your working directory is {{cwd}}.",
  "You are a coding agent powered by the {{model}} model. Your working directory is {{cwd}}.",
];
for (const [index, text] of fixtures.entries()) {
  test(`legacy persona ${index} renders with current Harness`, { skip: !rendererPath }, () => {
    const input = {
      variables,
      sections: [{ name: "deployment:persona-suffix", text, order: 10200 }],
      contexts: [context],
      tools: [],
    };
    const original = structuredClone(input);
    const output = rewritePromptAssembly(input, "", { capabilityProtocol: false });
    assert.doesNotThrow(() => renderPrompt(output));
    assert.deepEqual(input, original, "source assembly must not be mutated");
    assert.deepEqual(renderContextSections(output), [{ name: context.name, text: context.text }]);
  });
}
test("missing suffix does not reintroduce cwd", { skip: !rendererPath }, () => {
  const output = rewritePromptAssembly({ sections: [], variables, contexts: [context], tools: [] }, "", { capabilityProtocol: false });
  assert.doesNotThrow(() => renderPrompt(output));
  assert.ok(!output.sections.some(s => String(s.text).includes("{{cwd}}")));
});
test("legacy sentence removal preserves surrounding instructions", () => {
  assert.equal(removeLegacyCwdSentence("Before. Working directory: {{cwd}}. After."), "Before. After.");
  assert.equal(removeLegacyCwdSentence("Working directory: {{cwd}}.\r\nNext line."), "Next line.");
});
test("custom paths and other placeholders remain unchanged", () => {
  for (const text of ["Path: {{cwd}}/src", "Working directory: {{cwd}}/src", "Use {{model}} and {{provider}}", "Your working directory is /real/path."]) {
    assert.equal(removeLegacyCwdSentence(text), text);
  }
});
test("literal prompt text retains literal braces", { skip: !rendererPath }, () => {
  const assembly = { sections: [{ name: "custom", text: "Example: {{cwd}}", interpolate: false }], variables };
  assert.equal(renderPrompt(assembly), "Example: {{cwd}}");
});
test("unknown custom placeholders still produce a strict diagnostic", { skip: !rendererPath }, () => {
  assert.throws(() => renderPrompt({ sections: [{ name: "custom", text: "{{missing}}" }], variables }), /unknown prompt variable/);
});
test("old renderer remains compatible when cwd is registered", { skip: !rendererPath }, () => {
  const output = rewritePromptAssembly({ sections: [], variables: { ...variables, cwd: "/legacy/path" }, contexts: [], tools: [] }, "", { capabilityProtocol: false });
  assert.doesNotThrow(() => renderPrompt(output));
  assert.equal(output.variables.cwd, "/legacy/path");
});
test("bundle does not configure a legacy cwd suffix", async () => {
  const yaml = await readFile(new URL("../cordis.patch.yml", import.meta.url), "utf8");
  assert.match(yaml, /personaSuffix: ""/);
  assert.doesNotMatch(yaml, /personaSuffix:.*\{\{cwd\}\}/);
});
